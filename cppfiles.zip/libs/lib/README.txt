glfw3.lib is the Windows binary downloaded from https://www.glfw.org/download.

The version is lib-vc2022.